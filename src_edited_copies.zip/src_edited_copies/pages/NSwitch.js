import GameCard from "../GameCard.js";
const NSwitch = () => {
  return (
    <>
      <GameCard id={"smt5"} />
    </>
  );
};

export default NSwitch;
