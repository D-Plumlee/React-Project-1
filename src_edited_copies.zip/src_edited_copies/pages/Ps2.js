import GameCard from "../GameCard.js";
const Ps2 = () => {
  return (
    <>
      <GameCard id={"smt3"} />
    </>
  );
};

export default Ps2;
