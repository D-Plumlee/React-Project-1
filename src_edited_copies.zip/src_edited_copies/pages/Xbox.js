import GameCard from "../GameCard.js";
const Xbox = () => {
  return (
    <>
      <GameCard id={"smtNine"} />
    </>
  );
};

export default Xbox;
