import GameCard from "../GameCard.js";

const SuperFam = () => {
  return (
    <>
      <GameCard id={"smt1"} />
      <GameCard id={"smt2"} />
      <GameCard id={"smtIf"} />
    </>
  );
};

export default SuperFam;
