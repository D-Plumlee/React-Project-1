import GameCard from "../GameCard.js";
const ThreeDS = () => {
  return (
    <>
      <GameCard id={"smtSJ"} />
      <GameCard id={"smt4"} />
      <GameCard id={"smt4a"} />
    </>
  );
};

export default ThreeDS;
